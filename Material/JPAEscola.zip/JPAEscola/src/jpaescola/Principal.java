
package jpaescola;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;


public class Principal {

    //Cria objeto que gerenciará persistência
    static EntityManagerFactory fab = Persistence.createEntityManagerFactory("JPAEscolaPU"); 
    static EntityManager em = fab.createEntityManager(); 
    static EntityTransaction tx = em.getTransaction();
   
    public static void main(String[] args) {
        
        List<Aluno> lista = consultaTodos();
        
        for (Aluno aluno : lista) {
            
            System.out.println("Nome: " + aluno.getNome() 
                               + " CPF: " + aluno.getCpf());
        }
        
        /*
        try {  
          
            tx.begin();  //Inicia transação 
          
            Aluno a1 = new Aluno(); 
            a1.setNome("Pedro");
            a1.setCpf("5935798594");
            em.persist(a1); //Persiste primeiro aluno 
            
            System.out.println("Cadastrado com sucesso!");
          
            Aluno a2 = new Aluno(); 
            a2.setNome("Maria");
            a2.setCpf("05366556775");
            em.persist(a2); //Persiste segundo aluno
          
            tx.commit(); //Finaliza transação 
            
        } catch (Exception ex) { 
            tx.rollback(); //Rollback em caso de erro 
        } finally { 
            //Fechando as conexões com o BD MySQL
            em.close();
            fab.close(); 
        }
        */
        
      } 
    
    public static List<Aluno> consultaTodos(){
        List<Aluno> listaAlunos;
        try {
            Query q = em.createNamedQuery("Aluno.findAll");
            listaAlunos = q.getResultList();
        } catch (Exception e) {
            listaAlunos = new ArrayList();
        } finally{
            em.close();
        }
        return listaAlunos;   
    }
    
}
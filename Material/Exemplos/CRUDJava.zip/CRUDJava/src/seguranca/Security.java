package seguranca;

import java.io.UnsupportedEncodingException;
import java.security.*;

public class Security {
    
    public static String criptarSenha(String valor) throws NoSuchAlgorithmException, 
                                                           UnsupportedEncodingException{
       
        //Escolher o Algoritmo de criptografia
        MessageDigest algorithm = MessageDigest.getInstance("MD5");
        byte messageDigest[] = algorithm.digest(valor.getBytes("UTF-8"));
        
        //Executar a criptografia
        StringBuilder hexString = new StringBuilder();
        for (byte b : messageDigest) {
            hexString.append(String.format("%02X", 0xFF & b));
        }
        return hexString.toString();
    }
}
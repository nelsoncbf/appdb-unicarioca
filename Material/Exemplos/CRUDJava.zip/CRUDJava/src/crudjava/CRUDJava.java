package crudjava;

import apresentacao.JFrameLogin;

/**
 *
 * @author 07133859793
 */
public class CRUDJava {
    public static void main(String[] args) {
        JFrameLogin login = new JFrameLogin();
        login.setTitle("CONTROLE DE ACESSO");
        login.setLocationRelativeTo(null);
        login.setVisible(true);
    }
}
